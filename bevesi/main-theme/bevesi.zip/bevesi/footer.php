<?php
/**
 * footer.php
 * @package WordPress
 * @subpackage Bevesi
 * @since Bevesi 1.0
 * 
 */
 ?>
 
 
		</div><!-- main-content -->
		
		<?php bevesi_do_action( 'bevesi_before_main_footer'); ?>

		<?php if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'footer' ) ) { ?>
		
			<?php
			/**
			* Hook: bevesi_main_footer
			*
			* @hooked bevesi_main_footer_function - 10
			*/
			do_action( 'bevesi_main_footer' );
		
			?>
			
		<?php } ?>
		
		<?php bevesi_do_action( 'bevesi_after_main_footer'); ?>	
		
	</div><!-- page-content -->
  
	<?php wp_footer(); ?>
  
	</body>
</html>