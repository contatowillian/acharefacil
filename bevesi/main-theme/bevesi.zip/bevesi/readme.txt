=== Bevesi ===

Contributors: KlbTheme Team

Tags: light, dark, gray, red, responsive-layout, right-sidebar, left-sidebar, one-column, two-columns, three-columns, four-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-image-header, featured-images, full-width-template, microformats, post-formats, sticky-post, theme-options, threaded-comments, translation-ready

Requires at least: 5.0

Tested up to: 6.1.1

Stable tag: 1.0

License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Changelog ==



= RELEASE 1.0.0 =

* Initial Release