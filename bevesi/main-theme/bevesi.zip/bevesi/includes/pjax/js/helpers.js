var bevesiThemeModule = {};
/* global bevesi_settings */

(function($) {

	bevesiThemeModule.$window = $(window);

	bevesiThemeModule.$document = $(document);

	bevesiThemeModule.$body = $('body');


	
})(jQuery);